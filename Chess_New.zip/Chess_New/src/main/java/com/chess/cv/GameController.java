package com.chess.cv;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import com.chess.model.Player;

public class GameController {
	private static GameController gc;//reference for singleton method
	private Scanner sc = new Scanner(System.in);
	int status = 0;
	private boolean isDebug = false;
	private GameView gv = GameView.gv();
	private GameModel gm = GameModel.gm();
	private Player currentPlayer;

	static final int CANCELMOVE = 100;

	//checks if the instance is not null
	public static GameController gc() {
		if (gc == null) {
			gc = new GameController();
		}
		return gc;//returns the object
	}

	boolean isContinue() {
		return this.status != -2;
	}

	public boolean isDebug() {
		return this.isDebug;
	}

	public boolean isPrintPossibleMove() {
		return false;
	}

	boolean isMoveCancelled() {
		return this.status == CANCELMOVE;//100 is constants for canceling move
	}

	public Player getCurrentPlayer() {
		return this.currentPlayer;
	}

	public void setCurrentPlayer(Player currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	// change current player
	void flipPlayer() {
		this.currentPlayer = this.currentPlayer.isWhite() ? this.gm.getBlack() : this.gm.getWhite();
	}

	public void startGame(boolean isDebug) {
		this.startGame(false, isDebug);
	}

	void startGame(boolean isRestart, boolean isDebug) {
		this.isDebug = isDebug;
		this.gv.sc = this.sc;
		this.status = 0;
		this.gv.printHelp();
		if (!isRestart) {
			File setup = new File("data");
			File[] file = setup.listFiles();
			if (file != null && file.length > 0) {
				this.processFileData(file);
			} else {
				this.gm.intializeGame();
				this.loadGame();
			}
		} else {
			this.gm.intializeGame();
		}
		try {
			while (!this.gm.isGameOver() && this.status == 0) {
				this.gv.nextMove();
				if (!this.isContinue()) {
					break;
				}
			}
			if (this.status == 0) {
				this.gv.announceWinner();
			}
		} catch (Exception e) {
			//e.printStackTrace();
			this.sc.close();
		}
	}

	private void processFileData(File[] file) {
		String[] players = file[0].getName().split("_");
		this.gv.print("There was unfinished game " + players[0] + " VS " + players[1]);
		this.gv.print("Do you want to continue...Enter Y/N");
		String cmd = this.sc.next();
		if ("Y".equalsIgnoreCase(cmd)) {
			this.gm.loadGame(this.getSavedData(file[0]));
			this.gm.getBlack().setName(players[0]);
			this.gm.getWhite().setName(players[1]);
			this.setCurrentPlayer(players[2].startsWith("true") ? this.gm.getWhite() : this.gm.getBlack());
			this.gv.print("Game Loaded....");
			this.gv.drawBoard();
		} else {
			this.gm.intializeGame();
			this.loadGame();
		}
		try {
			file[0].delete();
		} catch (Exception ignoreForNow) {
		}
	}

	// Inputs from user when fresh game starts
	private void loadGame() {
		this.gv.print("Lets begin the game....");
		this.gv.print("Player 1, Enter your name...\n");
		String name = this.sc.next();
		this.gv.print("Choose color :");
		this.gv.print("Enter 'w' for White or 'b' for Black\n");
		String color = this.sc.next();
		if ("w".equalsIgnoreCase(color)) {// select Color
			this.setCurrentPlayer(this.gm.getWhite());
			this.gv.print("White selected by you.");
		} else if ("b".equalsIgnoreCase(color)) {
			this.setCurrentPlayer(this.gm.getBlack());
			this.gv.print("Black selected by you.");
		} else {
			this.gv.print("Invalid option selected. System selected 'White' for you :)\n");
			this.setCurrentPlayer(this.gm.getWhite());
		}
		this.getCurrentPlayer().setName(name);
		this.gv.print("Player 2,Enter your name...");
		if (this.getCurrentPlayer().isWhite()) {
			this.gm.getBlack().setName(this.sc.next());
		} else {
			this.gm.getWhite().setName(this.sc.next());
		}
	}

	// Loading  and reading saved file
	private char[][] getSavedData(File file) {
		char[][] chars = new char[8][8];
		try (Scanner inputStream = new Scanner(file)) {
			for (int x = 0; x < 8; x++) {
				String data = inputStream.nextLine();
				data = data.replaceAll("\"", "");
				String[] keyValue = data.split(",");
				for (int y = 0; y < 8; y++) {
					chars[x][y] = keyValue[y].trim().charAt(0);
				}
			}
		} catch (FileNotFoundException e) {
			this.gv.print("Invalid Data");
			//	e.printStackTrace();
		}
		return chars;
	}

}
