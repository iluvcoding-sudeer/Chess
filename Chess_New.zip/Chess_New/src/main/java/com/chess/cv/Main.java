package com.chess.cv;


public class Main {

	public static void main(String[] args) {
		boolean isDebug = false;// To Turn on debug mode , later take inputs from by args
		GameController.gc().startGame(isDebug);
	}
}
