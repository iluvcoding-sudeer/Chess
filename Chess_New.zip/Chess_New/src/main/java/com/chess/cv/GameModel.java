package com.chess.cv;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import com.chess.model.Bishop;
import com.chess.model.Cell;
import com.chess.model.King;
import com.chess.model.Knight;
import com.chess.model.Pawn;
import com.chess.model.Piece;
import com.chess.model.Player;
import com.chess.model.Queen;
import com.chess.model.Rook;

public class GameModel {
	Cell[][] cell = new Cell[8][8];
	private static GameModel gm;//reference for singleton method
	private Player white = new Player(true);
	private Player black = new Player(false);

	//checks if the instance is not null
	public static GameModel gm() {
		if (gm == null) { //checks for an instance
			gm = new GameModel(); //if it doesnt exist then a new object is made
		}
		return gm;//returns the object
	}

	public Cell[][] cellArray() {
		return this.cell;
	}

	public Player getWhite() {
		return this.white;
	}

	public void setWhite(Player white) {
		this.white = white;
	}

	public Player getBlack() {
		return this.black;
	}

	public void setBlack(Player black) {
		this.black = black;
	}

	void intializeGame() {
		for (int x = 0; x < 8; x++) {
			for (int y = 0; y < 8; y++) {
				this.cell[x][y] = new Cell(x, y);
			}
		}
		this.cell[0][0].setPiece(new Piece(new Rook(), false));
		this.cell[0][1].setPiece(new Piece(new Knight(), false));
		this.cell[0][2].setPiece(new Piece(new Bishop(), false));
		this.cell[0][3].setPiece(new Piece(new King(), false));
		this.cell[0][4].setPiece(new Piece(new Queen(), false));
		this.cell[0][5].setPiece(new Piece(new Bishop(), false));
		this.cell[0][6].setPiece(new Piece(new Knight(), false));
		this.cell[0][7].setPiece(new Piece(new Rook(), false));
		for (int y = 0; y < 8; y++) {
			this.cell[1][y].setPiece(new Piece(new Pawn(), false));
		}
		for (int x = 2; x < 6; x++) {
			for (int y = 0; y < 8; y++) {
				this.cell[x][y].setPiece(null);
			}
		}
		this.cell[7][0].setPiece(new Piece(new Rook(), true));
		this.cell[7][1].setPiece(new Piece(new Knight(), true));
		this.cell[7][2].setPiece(new Piece(new Bishop(), true));
		this.cell[7][3].setPiece(new Piece(new King(), true));
		this.cell[7][4].setPiece(new Piece(new Queen(), true));
		this.cell[7][5].setPiece(new Piece(new Bishop(), true));
		this.cell[7][6].setPiece(new Piece(new Knight(), true));
		this.cell[7][7].setPiece(new Piece(new Rook(), true));
		for (int y = 0; y < 8; y++) {
			this.cell[6][y].setPiece(new Piece(new Pawn(), true));
		}
		this.white.setKingCell(this.cell[0][3]);
		this.black.setKingCell(this.cell[7][3]);
	}

	public void loadGame(char[][] arr) {
		for (int x = 0; x < 8; x++) {
			for (int y = 0; y < 8; y++) {
				this.cell[x][y] = new Cell(x, y);
				if (arr[x][y] != '0') {
					this.setPiece(x, y, arr[x][y]);
				} else {
					this.cell[x][y].setPiece(null);
				}
			}
		}
	}

	private void setPiece(int x, int y, char c) {
		Piece piece = new Piece(c);
		this.cell[x][y].setPiece(piece);
		if (piece.isKing()) {
			this.setKingCell(this.cell[x][y]);
		}
	}

	// Setting King position on load of game
	private void setKingCell(Cell cell) {
		if (cell.isOccupiedByBlack()) {
			this.black.setKingCell(cell);
		} else {
			this.white.setKingCell(cell);
		}
	}

	public char[][] saveGame() {
		char[][] savearr = new char[8][8];
		for (int x = 0; x < 8; x++) {
			for (int y = 0; y < 8; y++) {
				savearr[x][y] = this.cell[x][y].printCell();
			}
		}
		return savearr;
	}

	boolean isGameOver() {
		return GameController.gc().getCurrentPlayer().isCheckMate();
	}

	// Writing file for state of Game
	private void writeStateToFile() {
		File fout = this.dataFile();
		try (FileOutputStream fos = new FileOutputStream(fout);
				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos))) {
			for (int x = 0; x < 8; x++) {
				for (int y = 0; y < 8; y++) {
					bw.write(this.cell[x][y].getCellChar());
					if (y != 7) {
						bw.write(",");
					}
				}
				bw.newLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private File dataFile() {
		File fout = new File(new File("data"), this.fileName());
		if (!fout.exists()) {
			try {
				fout.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return fout;
	}

	void saveAndExitGame() {
		this.writeStateToFile();
		GameView.gv().print("Game Saved and exited.");
		System.exit(0);
	}

	//BlackPlayerName_WhitePlayerName_CurrentPlayer.isWhite.txt
	private String fileName() {
		return this.getBlack().getName() + "_" + this.getWhite().getName() + "_" + GameController.gc().getCurrentPlayer().isWhite() + ".txt";
	}

	//This validates if current move is getting check, then it will be invalid move
	public boolean isNotGettingCheck(Cell from, Cell toCell) {
		boolean isNotGettingCheck = true;
		Piece currentPiece = toCell.getPiece();
		from.moveToCell(toCell);// Temporarily moving piece for checking test
		Player player = GameController.gc().getCurrentPlayer();
		Player enemy = player.getEnemySide();
		Cell kingCell = player.kingCell();
		for (Cell enemyCell : enemy.getOccupiedCells()) {
			if (enemyCell.possibleMoves().contains(kingCell)) {
				isNotGettingCheck = false;
				GameView.gv().errorMsg = player.getPlayerName() + ",Invalid move as you are getting check by this move.";
			}
		}
		from.revertMove(toCell, currentPiece);// reverting move
		return isNotGettingCheck;
	}

}