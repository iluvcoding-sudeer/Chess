package com.chess.model;


import java.util.ArrayList;
import java.util.List;

public class Bishop extends PieceType {

	@Override
	public char printCell() {
		return 'B';
	}

	@Override
	public boolean isValid(Cell from, Cell to) {
		return this.isValidDiagonalMove(from, to);
	}

	@Override
	public List<Cell> possibleMoves(Cell cell) {
		List<Cell> possibleMoves = new ArrayList<>();
		possibleMoves.addAll(this.diagonalMoves(cell));
		return possibleMoves;
	}

}
