package com.chess.model;

import java.util.ArrayList;
import java.util.List;

import com.chess.cv.GameController;
import com.chess.cv.GameModel;

public class Player {
	private String name;
	private boolean isWhite;
	private Cell kingCell;// for getting to know if being check on move

	public Player(boolean isWhite) {
		super();
		this.isWhite = isWhite;
	}

	public boolean isWhite() {
		return this.isWhite;
	}

	public void setWhite(boolean isWhite) {
		this.isWhite = isWhite;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Cell kingCell() {
		return this.kingCell;
	}

	public String getPlayerName() {
		return this.name + "(" + (this.isWhite ? "White" : "Black") + ")";
	}

	public Player getEnemySide() {
		return this.isWhite() ? GameModel.gm().getBlack() : GameModel.gm().getWhite();
	}

	public List<Cell> getOccupiedCells() {
		return this.isWhite() ? this.getWhiteCells() : this.getBlackCells();
	}

	private List<Cell> getBlackCells() {
		List<Cell> cells = new ArrayList<>();
		for (int row = 0; row < 8; row++) {
			for (int column = 0; column < 8; column++) {
				Cell cell = GameModel.gm().cellArray()[row][column];
				if (cell.isOccupiedByBlack()) {
					cells.add(cell);
				}
			}
		}
		return cells;
	}

	private List<Cell> getWhiteCells() {
		List<Cell> cells = new ArrayList<>();
		for (int row = 0; row < 8; row++) {
			for (int column = 0; column < 8; column++) {
				Cell cell = GameModel.gm().cellArray()[row][column];
				if (cell.isOccupiedByWhite()) {
					cells.add(cell);
				}
			}
		}
		return cells;
	}

	public boolean isInCheck() {
		Player enemy = this.getEnemySide();
		for (Cell enemyCell : enemy.getOccupiedCells()) {
			if (GameController.gc().isPrintPossibleMove()) {
				enemyCell.printPossibleMoves();//Print
			}
			if (enemyCell.possibleMoves().contains(this.kingCell())) {
				return true;
			}
		}
		return false;
	}

	public boolean isCheckMate() {
		boolean isCheckMate = false;
		if (this.isInCheck()) {
			isCheckMate = true;
			for (Cell cell : this.getOccupiedCells()) {
				isCheckMate = cell.isCheckMate(this);
				if (!isCheckMate) {
					break;
				}
			}
		}
		return isCheckMate;
	}

	public void setKingCell(Cell toCell) {
		this.kingCell = toCell;
	}
}
