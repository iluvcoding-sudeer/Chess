package com.chess.model;

import java.util.ArrayList;
import java.util.List;

import com.chess.cv.GameModel;
import com.chess.cv.GameView;

public abstract class PieceType {
	public static final int SIZE = 8;

	public abstract char printCell();

	public abstract boolean isValid(Cell from, Cell to);

	public boolean isCorrectMove(Cell from, Cell to) {
		if (this.isValid(from, to)) {
			return GameModel.gm().isNotGettingCheck(from, to);
		}
		return false;
	}

	public abstract List<Cell> possibleMoves(Cell cell);

	/**
	 * X++ and Y++
	 */
	private boolean x4(Cell from, Cell to) {
		for (int j = from.getY() + 1, i = from.getX() + 1; j < to.getY() && i <= to.getX(); j++, i++) {
			Cell cell = this.getCell(i, j);
			if (!cell.isEmpty()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * X++ and Y--
	 * 
	 * @param from
	 * @param to
	 * @return
	 */
	private boolean x3(Cell from, Cell to) {
		for (int j = from.getY() - 1, i = from.getX() + 1; j > -1 && i <= to.getX(); j--, i++) {
			Cell cell = this.getCell(i, j);
			if (!cell.isEmpty()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * X-- and Y++
	 * 
	 * @param from
	 * @param to
	 * @return
	 */
	private boolean x2(Cell from, Cell to) {
		for (int j = from.getY() + 1, i = from.getX() - 1; j <= to.getY() && i > -1; j++, i--) {
			Cell cell = this.getCell(i, j);
			if (!cell.isEmpty()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * X-- and Y--
	 * 
	 * @param from
	 * @param to
	 * @return
	 */
	private boolean x1(Cell from, Cell to) {
		for (int j = from.getY() - 1, i = from.getX() - 1; j > -1 && i > -1; j--, i--) {
			Cell cell = this.getCell(i, j);
			if (!cell.isEmpty()) {
				return false;
			}
		}
		return true;
	}

	//absolute value should be same
	//increment one by one to check if there is any other piece
	protected boolean isValidDiagonalMove(Cell from, Cell to) {
		if (Math.abs(from.getX() - to.getX()) == Math.abs(from.getY() - to.getY())) {
			int xDiff = from.getX() - to.getX();
			int yDiff = from.getY() - to.getY();
			if (xDiff < 0) {
				if (yDiff < 0) {
					return this.x1(from, to);
				} else {
					return this.x2(from, to);
				}
			} else {
				if (yDiff < 0) {
					return this.x3(from, to);
				} else {
					return this.x4(from, to);
				}
			}
		}
		return false;
	}

	protected boolean isValidLinearMove(Cell from, Cell to) {
		if (from.getX() == to.getX()) {
			for (int i = from.getY() + 1; i < to.getY(); i++) {
				if (!this.getCell(from.getX(), i).isEmpty()) {
					return false;
				}
			}
			return true;
		} else if (from.getY() == to.getY()) {
			for (int i = from.getX() + 1; i < to.getX(); i++) {
				if (!this.getCell(i, from.getY()).isEmpty()) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	public boolean isPawn() {
		return false;
	}

	public boolean isKing() {
		return false;
	}

	protected Cell getCell(int i, int j) {
		return GameModel.gm().cellArray()[i][j];
	}

	public void printPossibleMoves(Cell cell) {
		for (Cell loopCell : this.possibleMoves(cell)) {
			GameView.gv().print(loopCell.coordinates());
		}
	}

	protected ArrayList<Cell> diagonalMoves(Cell cell) {
		ArrayList<Cell> possibleDiagMoves = new ArrayList<>();
		int row = cell.getX();
		int column = cell.getY();
		//all possible moves in the down positive diagonal
		for (int j = column + 1, i = row + 1; j < SIZE && i < SIZE; j++, i++) {
			Cell targetCell = this.getCell(i, j);
			if (targetCell.isEmpty()) {
				possibleDiagMoves.add(targetCell);
			} else if (cell.isOpponent(targetCell)) {
				possibleDiagMoves.add(targetCell);
				break;
			} else {
				break;
			}
		}
		//all possible moves in the up positive diagonal
		for (int j = column - 1, i = row + 1; j > -1 && i < SIZE; j--, i++) {
			Cell targetCell = this.getCell(i, j);
			if (targetCell.isEmpty()) {
				possibleDiagMoves.add(targetCell);
			} else if (cell.isOpponent(targetCell)) {
				possibleDiagMoves.add(targetCell);
				break;
			} else {
				break;
			}
		}
		//all possible moves in the up negative diagonal
		for (int j = column - 1, i = row - 1; j > -1 && i > -1; j--, i--) {
			Cell targetCell = this.getCell(i, j);
			if (targetCell.isEmpty()) {
				possibleDiagMoves.add(targetCell);
			} else if (cell.isOpponent(targetCell)) {
				possibleDiagMoves.add(targetCell);
				break;
			} else {
				break;
			}
		}
		//all possible moves in the down negative diagonal
		for (int j = column + 1, i = row - 1; j < SIZE && i > -1; j++, i--) {
			Cell targetCell = this.getCell(i, j);
			if (targetCell.isEmpty()) {
				possibleDiagMoves.add(targetCell);
			} else if (cell.isOpponent(targetCell)) {
				possibleDiagMoves.add(targetCell);
				break;
			} else {
				break;
			}
		}
		return possibleDiagMoves;
	}

	protected ArrayList<Cell> linearMoves(Cell cell) {
		ArrayList<Cell> possibleLinearMoves = new ArrayList<>();
		//all possible moves in the up
		this.addXPlusMove(cell, possibleLinearMoves);
		//all possible moves in the down
		this.addXMinusMove(cell, possibleLinearMoves);
		//all possible moves to the right
		this.addYPlusMove(cell, possibleLinearMoves);
		//all possible moves to the left
		this.addYMinusMove(cell, possibleLinearMoves);
		return possibleLinearMoves;
	}

	private void addXPlusMove(Cell cell, ArrayList<Cell> possibleLinearMoves) {
		for (int i = cell.getX() + 1; i < SIZE; i++) {
			Cell moveCell = this.getCell(i, cell.getY());
			if (moveCell.isEmpty()) {
				possibleLinearMoves.add(moveCell);
			} else if (cell.isOpponent(moveCell)) {
				possibleLinearMoves.add(moveCell);
				break;
			} else {
				break;
			}
		}
	}

	private void addXMinusMove(Cell cell, ArrayList<Cell> possibleLinearMoves) {
		for (int i = cell.getX() - 1; i > -1; i--) {
			Cell moveCell = this.getCell(i, cell.getY());
			if (moveCell.isEmpty()) {
				possibleLinearMoves.add(moveCell);
			} else if (cell.isOpponent(moveCell)) {
				possibleLinearMoves.add(moveCell);
				break;
			} else {
				break;
			}
		}
	}

	private void addYPlusMove(Cell cell, ArrayList<Cell> possibleLinearMoves) {
		for (int i = cell.getY() + 1; i < SIZE; i++) {
			Cell moveCell = this.getCell(cell.getX(), i);
			if (moveCell.isEmpty()) {
				possibleLinearMoves.add(moveCell);
			} else if (cell.isOpponent(moveCell)) {
				possibleLinearMoves.add(moveCell);
				break;
			} else {
				break;
			}
		}
	}

	private void addYMinusMove(Cell cell, ArrayList<Cell> possibleLinearMoves) {
		for (int i = cell.getY() - 1; i > -1; i--) {
			Cell moveCell = this.getCell(cell.getX(), i);
			if (moveCell.isEmpty()) {
				possibleLinearMoves.add(moveCell);
			} else if (cell.isOpponent(moveCell)) {
				possibleLinearMoves.add(moveCell);
				break;
			} else {
				break;
			}
		}
	}
}
