package com.chess.model;


import java.util.ArrayList;
import java.util.List;

public class Rook extends PieceType {

	@Override
	public char printCell() {
		return 'R';
	}

	@Override
	public boolean isValid(Cell from, Cell to) {
		return this.isValidLinearMove(from, to);
	}

	@Override
	public List<Cell> possibleMoves(Cell cell) {
		List<Cell> possibleMoves = new ArrayList<>();
		possibleMoves.addAll(this.linearMoves(cell));
		return possibleMoves;
	}
}
