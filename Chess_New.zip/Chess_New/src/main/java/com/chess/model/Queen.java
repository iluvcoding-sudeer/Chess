package com.chess.model;


import java.util.ArrayList;
import java.util.List;

public class Queen extends PieceType {

	@Override
	public char printCell() {
		return 'Q';
	}

	@Override
	public boolean isValid(Cell from, Cell to) {
		return this.isValidDiagonalMove(from, to) || this.isValidLinearMove(from, to);
	}

	@Override
	public List<Cell> possibleMoves(Cell cell) {
		List<Cell> possibleMoves = new ArrayList<>();
		possibleMoves.addAll(this.diagonalMoves(cell));
		possibleMoves.addAll(this.linearMoves(cell));
		return possibleMoves;
	}
}
