package com.chess.cv;

import java.util.Scanner;

import com.chess.model.Cell;

public class GameView {
	private static final String LINESEP = "\t-----------------------------------";
	private static GameView gv;//reference for singleton method
	Scanner sc;
	String errorMsg;

	//checks if the instance is not null
	public static GameView gv() {
		if (gv == null) { //checks for an instance
			gv = new GameView(); //if it doesnt exist then a new object is made
		}
		return gv;//returns the object
	}

	private GameController gc() {
		return GameController.gc();
	}

	void drawBoard() {
		this.print("\t\t" + GameModel.gm().getWhite().getName() + "(WHITE)");
		this.print(LINESEP);
		System.out.print("\t  ");
		for (int column = 0; column < 8; column++) {
			if (column == 7) {
				this.print("|" + column + "y |");
			} else {
				System.out.print("|" + column + "y ");
			}
		}
		for (int row = 0; row < 8; row++) {
			this.print(LINESEP);
			for (int column = 0; column < 8; column++) {
				if (column == 7) {
					this.print("| " + GameModel.gm().cell[row][column].symbol() + " |" + row + "x");
				} else if (column == 0) {
					System.out.print("\t" + row + "x| " + GameModel.gm().cell[row][column].symbol() + " ");
				} else {
					System.out.print("| " + GameModel.gm().cell[row][column].symbol() + " ");
				}
			}
		}
		this.print(LINESEP);
		System.out.print("\t  ");
		for (int column = 0; column < 8; column++) {
			if (column == 7) {
				this.print("|" + column + "y |");
			} else {
				System.out.print("|" + column + "y ");
			}
		}
		this.print(LINESEP);
		this.print("\t\t" + GameModel.gm().getBlack().getName() + "(BLACK)");
	}

	//check if the piece is occupied
	//check if is piece belongs to current player
	///from cell send isValid
	public void nextMove() {
		if (this.gc().getCurrentPlayer().isInCheck()) {
			this.print("******************" + this.gc().getCurrentPlayer().getPlayerName() + ", You are on Check. Save your KING.");
		}
		this.gc().status = 0;
		this.drawBoard();
		Cell fromCell = null;
		while (this.gc().isContinue()) {
			fromCell = this.getCell(false);
			if (this.isPeiceBelongToPlayer(fromCell)) {
				break;
			} else {
				this.print("Invalid From position.");
			}
		}
		this.print("Great, you selected " + fromCell.location());
		this.move(fromCell);
		if (this.gc().isMoveCancelled()) {
			this.nextMove();
		} else {
			this.gc().flipPlayer();
		}
	}

	private void move(Cell fromCell) {
		Cell toCell;
		while (this.gc().isContinue()) {
			toCell = this.getCell(true);
			if (fromCell.isValid(toCell)) {
				fromCell.moveToCell(toCell);
				fromCell.postMove(toCell);
				break;
			} else {
				if (this.gc().isMoveCancelled()) {
					break;
				} else if (this.errorMsg != null) {
					this.print(this.errorMsg);
					this.errorMsg = null;
				} else if (toCell != null) {
					this.print("Invalid move" + toCell.location() + " for " + fromCell.location() + ". Try again...");
				} else {
					this.print("Invalid move. Try again...");
				}
				this.print("Enter '" + GameController.CANCELMOVE + "' anytime to reset move or 'Help' for commands.");
				this.drawBoard();
			}
		}
	}

	private Cell getCell(boolean isTO) {
		int x;
		this.print(this.gc().getCurrentPlayer().getPlayerName() + ",Enter the X position (0-7) " + (isTO ? "TO" : "FROM") + " where you want to move ");
		x = this.getInputAndParse();
		if (!this.gc().isMoveCancelled()) {
			while ((x >= 8 || x < 0) && this.gc().isContinue()) {
				this.print("Invalid entry");
				x = this.getInputAndParse();
				if (isTO && x == GameController.CANCELMOVE) {
					break;
				}
			}
		}
		int y = this.getY(isTO);
		return this.gc().isMoveCancelled() ? null : GameModel.gm().cell[x][y];
	}

	private int getY(boolean isTO) {
		int y = 0;
		if (!this.gc().isMoveCancelled()) {
			this.print(this.gc().getCurrentPlayer().getPlayerName() + ",Enter the Y position (0-7) " + (isTO ? "TO" : "FROM") + " where you want to move ");
			y = this.getInputAndParse();
			while ((y >= 8 || y < 0) && this.gc().isContinue()) {
				this.print("Invalid entry.");
				y = this.getInputAndParse();
				if (isTO && y == GameController.CANCELMOVE) {
					break;
				}
			}
		}
		return y;
	}

	private int getInputAndParse() {
		int intCmd = 0;
		try {
			String cmd = this.sc.next();
			switch (cmd.toLowerCase()) {
			case "save":
				GameModel.gm().saveAndExitGame();
				break;
			case "quit":
				this.quitGame();
				break;
			case "exit":
				this.exitGame();
				break;
			case "restart":
				this.restartGame();
				break;
			case "help":
				this.printHelp();
				break;
			default:
				intCmd = Integer.parseInt(cmd);
				break;
			}
		} catch (Exception e) {
			intCmd = -1;
		}
		if (intCmd == GameController.CANCELMOVE) {
			this.gc().status = GameController.CANCELMOVE;
		}
		return intCmd;
	}

	void printHelp() {
		this.print("Enter 'EXIT' to exit without saving any time.");
		this.print("Enter 'SAVE' to Save and exit after saving game any time.");
		this.print("Enter 'QUIT' to quit game anytime. Other player will be winner in that case.");
		this.print("Enter 'RESET' to reset and continue game.");
		this.print("Enter 'HELP' for getting List of Commands.");
	}

	private void quitGame() {
		this.announceWinner();
		this.safeExit();
	}

	private void exitGame() {
		this.print("Game exited without save.");
		this.safeExit();
	}

	private void restartGame() {
		this.print("Game is restarted.");
		this.gc().status = -2;
		this.gc().startGame(true);// restarting
	}

	private void safeExit() {
		System.exit(0);
	}

	private boolean isPeiceBelongToPlayer(Cell fromCell) {
		return fromCell != null && (this.gc().getCurrentPlayer().isWhite() ? fromCell.isOccupiedByWhite() : fromCell.isOccupiedByBlack());
	}

	void announceWinner() {
		this.drawBoard();
		this.print("Congratulations!!! " + this.gc().getCurrentPlayer().getName() + " win");
	}

	// Centralized so later can be used for logging easily
	public void print(String lineStr) {
		System.out.println(lineStr);
	}
}
