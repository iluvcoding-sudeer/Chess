package com.chess.model;


import java.util.ArrayList;
import java.util.List;

public class Pawn extends PieceType {

	boolean isPromotedAsQueen;

	@Override
	public char printCell() {
		return this.isPromotedAsQueen ? 'G' : 'P';
	}

	@Override
	public boolean isPawn() {
		return true;
	}

	@Override
	public boolean isValid(Cell from, Cell to) {
		return this.isPromotedAsQueen ? this.isValidQueenMove(from, to) : this.isValidPawnMove(from, to);
	}

	public boolean isFirstPawnMove(Cell from) {
		return from.getX() == 1 || from.getX() == 6;
	}

	private boolean isValidPawnMove(Cell from, Cell to) {
		if (to.getY() == from.getY()) {
			int val = Math.abs(to.getX() - from.getX());
			return val == 1 || (this.isFirstPawnMove(from) && val == 2);
		}
		return false;
	}

	private boolean isValidQueenMove(Cell from, Cell to) {
		return this.isValidDiagonalMove(from, to) || this.isValidLinearMove(from, to);
	}

	private List<Cell> possibleQueenMoves(Cell cell) {
		List<Cell> possibleMoves = new ArrayList<>();
		possibleMoves.addAll(this.diagonalMoves(cell));
		possibleMoves.addAll(this.linearMoves(cell));
		return possibleMoves;
	}

	@Override
	public List<Cell> possibleMoves(Cell cell) {
		if (this.isPromotedAsQueen) {
			return this.possibleQueenMoves(cell);
		}
		List<Cell> possibleMoves = new ArrayList<>();
		boolean isWhite = cell.isWhite();
		int dx = isWhite ? 1 : -1;
		Cell ahead = cell.neighbour(dx, 0);
		if (ahead.piece == null) {
			possibleMoves.add(ahead);
			if (cell.getX() == 6 && isWhite) {
				Cell aheadsecond = cell.neighbour(dx - 1, 0);
				if (aheadsecond.piece == null) {
					possibleMoves.add(aheadsecond);
				}
			} else if (cell.getX() == 1 && !isWhite) {
				Cell aheadsecond = cell.neighbour(dx + 1, 0);
				if (aheadsecond.piece == null) {
					possibleMoves.add(aheadsecond);
				}
			}
		}
		Cell aheadLeft = cell.neighbour(dx, -1);
		if (aheadLeft != null && aheadLeft.piece != null && cell.isOpponent(aheadLeft)) {
			possibleMoves.add(aheadLeft);
		}
		Cell aheadRight = cell.neighbour(dx, 1);
		if (aheadRight != null && aheadRight.piece != null && cell.isOpponent(aheadRight)) {
			possibleMoves.add(aheadRight);
		}
		return possibleMoves;
	}
}
