package com.chess.model;


import java.util.ArrayList;
import java.util.List;

public class Knight extends PieceType {
	int[][] offsets = { { -2, 1 }, { -1, 2 }, { 1, 2 }, { 2, 1 }, { 2, -1 }, { 1, -2 }, { -1, -2 }, { -2, -1 } };

	@Override
	public char printCell() {
		return 'N';
	}

	@Override
	public boolean isValid(Cell from, Cell to) {
		int fromX = from.getX();
		int fromY = from.getY();
		int toX = to.getX();
		int toY = to.getY();
		boolean isValid = true;
		if (toX != fromX - 1 && toX != fromX + 1 && toX != fromX + 2 && toX != fromX - 2) {
			isValid = false;
		} else if (toY != fromY - 2 && toY != fromY + 2 && toY != fromY - 1 && toY != fromY + 1) {
			isValid = false;
		}
		return isValid;
	}

	@Override
	public List<Cell> possibleMoves(Cell cell) {
		List<Cell> possibleMoves = new ArrayList<>();
		for (int[] o : this.offsets) {
			Cell nghr = cell.neighbour(o[0], o[1]);
			if (nghr != null && nghr.isAvailableCell(cell)) {
				possibleMoves.add(nghr);
			}
		}
		return possibleMoves;
	}
}
