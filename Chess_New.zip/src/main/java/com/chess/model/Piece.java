package com.chess.model;


public class Piece {

	boolean isBlack;
	PieceType type;
	Cell cell;

	public Piece(PieceType atype, boolean isBlack) {
		this.isBlack = isBlack;
		this.type = atype;

	}

	public Piece(char c) {
		if (Character.isLowerCase(c)) {
			this.isBlack = true;
		} else {
			this.isBlack = false;
		}
		switch (Character.toLowerCase(c)) {
		case 'k':
			this.type = new King();
			break;
		case 'b':
			this.type = new Bishop();
			break;
		case 'q':
			this.type = new Queen();
			break;
		case 'n':
			this.type = new Knight();
			break;
		case 'p':
			this.type = new Pawn();
			break;
		case 'g':
			Pawn pawn = new Pawn();
			pawn.isPromotedAsQueen = true;
			this.type = pawn;
			break;
		case 'r':
			this.type = new Rook();
			break;
		default:
			break;
		}
	}

	public char printCell() {
		if (this.type == null) {
			return ' ';
		} else if (this.isBlack) {
			return Character.toLowerCase(this.type.printCell());
		} else {
			return this.type.printCell();
		}
	}

	public boolean isValid(Cell toCell) {
		if (this.isPawn()) {
			if (toCell.isEmpty()) {
				return this.type.isCorrectMove(this.cell, toCell);
			} else {
				return (this.isBlack ? toCell.isOccupiedByWhite() : toCell.isOccupiedByBlack()) && this.isValidDiagonalPawnMove(toCell);
			}
		} else {
			return (toCell.isEmpty() || (this.isBlack ? toCell.isOccupiedByWhite() : toCell.isOccupiedByBlack())) && this.type.isCorrectMove(this.cell, toCell);
		}
	}

	private boolean isValidDiagonalPawnMove(Cell to) {
		return Math.abs(this.cell.getX() - to.getX()) == 1 && Math.abs(this.cell.getY() - to.getY()) == 1;
	}

	public boolean isKing() {
		return this.type != null && this.type.isKing();
	}

	public boolean isPawn() {
		return this.type != null && this.type.isPawn();
	}
}
