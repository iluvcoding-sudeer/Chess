package com.chess.model;

import java.util.ArrayList;
import java.util.List;

public class King extends PieceType {
	int[][] offsets = { { 1, 0 }, { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 1 }, { -1, 1 }, { -1, -1 }, { 1, -1 } };

	@Override
	public boolean isKing() {
		return true;
	}

	@Override
	public char printCell() {
		return 'K';
	}

	@Override
	public boolean isValid(Cell from, Cell to) {
		int dist2 = (int) (Math.pow((double) to.getX() - from.getX(), 2) + Math.pow((double) to.getY() - from.getY(), 2));
		return dist2 == 1 || dist2 == 2;
	}

	@Override
	public List<Cell> possibleMoves(Cell cell) {
		List<Cell> possibleMoves = new ArrayList<>();
		for (int[] o : this.offsets) {
			Cell target = cell.neighbour(o[0], o[1]);
			if (cell.isOpponent(target)) {
				possibleMoves.add(target);
			}
		}
		return possibleMoves;
	}
}
