package com.chess.model;

import java.util.ArrayList;
import java.util.List;

import com.chess.cv.GameController;
import com.chess.cv.GameModel;
import com.chess.cv.GameView;

public class Cell {

	Piece piece;
	private int x;
	private int y;

	public Cell(int x2, int y2) {
		this.x = x2;
		this.y = y2;
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Piece getPiece() {
		return this.piece;
	}

	public void setPiece(Piece piece) {
		this.piece = piece;
		if (piece != null) {
			piece.cell = this;
		}
	}

	public boolean isSameCell(Cell to) {
		return this.x == to.x && this.y == to.y;
	}

	public boolean isEmpty() {
		return this.piece == null;
	}

	public boolean isOccupiedByWhite() {
		return this.piece != null && !this.piece.isBlack;
	}

	public boolean isOccupiedByBlack() {
		return this.piece != null && this.piece.isBlack;
	}

	public String coordinates() {
		return "(" + this.x + "," + this.y + ")";
	}

	public String symbol() {
		if (GameController.gc().isDebug()) {
			return this.printWithCordinates();
		}
		return Character.toString(this.printCell());
	}

	private String printWithCordinates() {
		return this.printCell() + this.coordinates();
	}

	public char printCell() {
		char ch;
		if (this.piece == null) {
			return ' ';
		} else {
			ch = this.piece.printCell();
		}
		return ch;
	}

	public char getCellChar() {
		char ch;
		if (this.piece == null) {
			return '0';
		} else {
			ch = this.piece.printCell();
		}
		return ch;
	}

	public boolean isValid(Cell toCell) {
		if (toCell == null || this.isSameCell(toCell)) {
			return false;
		}
		return this.piece.isValid(toCell);
	}

	public void moveToCell(Cell toCell) {
		toCell.setPiece(this.piece);
		this.piece = null;
	}

	public void postMove(Cell toCell) {
		if (this.isKing()) {
			GameController.gc().getCurrentPlayer().setKingCell(toCell);
		}
		this.promotePawnToQueenIfNeeded();
	}

	public String location() {
		return this.printCell() + "(" + this.x + "," + this.y + ")";
	}

	public boolean isAvailableCell(Cell cell) {
		return cell.piece.isBlack ? this.isOccupiedByWhite() : this.isOccupiedByBlack();
	}

	public Cell neighbour(int i, int j) {
		int row = this.x + i;
		int column = this.y + j;
		if (row < 8 && column < 8 && row >= 0 && column >= 0) {
			return GameModel.gm().cellArray()[row][column];
		}
		return null;
	}

	public boolean isWhite() {
		return this.piece != null && !this.piece.isBlack;
	}

	public boolean isKing() {
		return this.piece != null && this.piece.isKing();
	}

	public boolean isOpponent(Cell targetCell) {
		return targetCell != null && !targetCell.isEmpty() && (this.isWhite() ? targetCell.isOccupiedByBlack() : targetCell.isOccupiedByWhite());
	}

	public void removePiece() {
		this.piece = null;
	}

	public List<Cell> possibleMoves() {
		if (this.isEmpty()) {
			return new ArrayList<>();
		} else {
			return this.piece.type.possibleMoves(this);
		}
	}

	public void revertMove(Cell toCell, Piece piece) {
		this.setPiece(toCell.piece);
		toCell.piece = piece;
	}

	public void printPossibleMoves() {
		if (!this.isEmpty()) {
			GameView.gv().print("Possible moves for " + this.printWithCordinates());
			this.piece.type.printPossibleMoves(this);
			GameView.gv().print("*********************************************************************");
		}
	}

	private boolean isAtEnemyLastEnd() {
		return this.isWhite() ? this.x == 7 : this.x == 0;
	}

	//called by postMove
	private void promotePawnToQueenIfNeeded() {
		//if pawn at end of enemy change its type to Queen
		//Symbol same but will get moves of queen
		if (!this.isEmpty() && this.piece.isPawn() && this.isAtEnemyLastEnd()) {
			((Pawn) this.piece.type).isPromotedAsQueen = true;
		}
	}

	public boolean isCheckMate(Player player) {
		boolean isCheckMate = true;
		for (Cell targetCell : this.possibleMoves()) {
			Piece currentPiece = targetCell.piece;
			this.moveToCell(targetCell);
			if (!player.isInCheck()) {
				isCheckMate = false;
				this.revertMove(targetCell, currentPiece);
				break;
			}
			this.revertMove(targetCell, currentPiece);
		}
		return isCheckMate;
	}
}
